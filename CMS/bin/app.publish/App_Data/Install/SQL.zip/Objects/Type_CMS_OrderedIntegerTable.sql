CREATE TYPE [dbo].[Type_CMS_OrderedIntegerTable] AS TABLE(
	[Value] [int] NOT NULL,
	PRIMARY KEY CLUSTERED 
(
	[Value] ASC
)WITH (IGNORE_DUP_KEY = OFF)
)
GO
