SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION Func_CMS_Routing_NumberOfCollidingAlternativeUrls(@path nvarchar(2000), @pathHash nvarchar(64), @siteId int)
RETURNS int
AS 
BEGIN
	IF LEN(@path) > 450
	BEGIN
		RETURN 0
	END
	DECLARE @rowcount int
	SELECT @rowcount = COUNT(*) 
		FROM CMS_AlternativeUrl 
		WHERE CONVERT(NVARCHAR(64), HASHBYTES('SHA2_256', LOWER(AlternativeUrlUrl)), 2) = @pathHash and AlternativeUrlSiteID = @siteId
	RETURN @rowcount
END;
GO
